This directory is used to store compiler files.

To compile files: Add them to the "files" folder and run the "compile.bat" program